<?php

require_once 'DB.php';

//Set Site Title, Email and Domain
$SiteTitle = "Post expiring reminder";
$SiteEmail = "info@mydomain.com";
$SiteURL   = "http://mydomain.com"; 
///////////////////////////////////

$today = date('Y-m-d');
$late_days = 60;
$latedate = date('Y-m-d', strtotime( "$today - $late_days days" ));


try{
    $sql = "SELECT id, email, created_at FROM posts
    WHERE created_at = :LateDate";
    
    $query = $db->prepare($sql); 
    $query->bindParam(":LateDate", $latedate);
    $query->execute();
    
    //Build data array
    $data = array();
    while($row = $query->fetch(PDO::FETCH_ASSOC)){
        $data[$row['id']]['id'] = $row['id'];
        $data[$row['id']]['name'] = $row['name'];
        $data[$row['id']]['email'] = $row['email'];);  
    }
    //
    if(!empty($data)):
    
        foreach($data as $id => $arr):
            //SENDING EMAIL FOR THE USER OR SAVE DATA IN DB
            
            //60 date completed on today
            $mail_subject = $SiteTitle;  
            $noticetype = "Expiring Reminder";                 
            $due_date = date('l, F d, Y', strtotime($latedate));
            $message = "This is a courtesy reminder that your post is expiring on today. If you want to keep your post available for next 6o days Please contact our support team.";
            
            $messageBottom = "Thank you<br />" . $SiteTitle;
            
            
            // format message             
            $todays_date = date('l, F d, Y', strtotime($today));
            $mailmsg ="";
            $mailmsg .= "<h2 style='text-align: center'>" . $noticetype . "</h2>";
            $mailmsg .= "<p><span style='float:right;padding-right:30px;'>" . $todays_date . "</span>Hello " . $data[$id]['name'] . ",</p>"; 
            $mailmsg .= "<p>" . $message . "</p>\r";
             
            $mailmsg .= "<p>" . $messageBottom . "</p>\r"; 
            
            //Double tables are the most reliable centering for emails
            $mail_body = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
            <html>
                <head>
                <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
                </head>
                <body>
                    <center>
                        <table width=98% border=\"0\" align=\"center\" cellpadding=1 cellspacing=\"0\" >
                            <tr>
                                <td align=\"center\" valign=\"top\">
                                    <table width=900px border=\"0\"  cellpadding=\"0\" cellspacing=\"0\" style='border:2px solid; border-color:#969696'>
                                        <tr>                                            
                                            <td bgcolor=\"#FFFFFF\" align=\"left\" style=\"padding:14px;\">" . $mailmsg . "</td>                                            
                                        </tr>
                                        <tr>
                                            <td bgcolor=#606060 align=\"center\" style=\"padding:2px; border-top:2px solid; border-color:#777777\">
                                                <a href=\"" . $SiteURL . "\" style='color:#ffffff; text-decoration:none'>" . $SiteTitle . "</a>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </center>
                </body>
            </html>"; 
            $mail_to = $data[$id]['email'];
            $headers = "From: \"$SiteTitle\" <$SiteEmail>\r\n";
            $headers .= "Reply-To: $SiteEmail\r\n";
            $headers .= "Organization: $SiteTitle \r\n";
            $headers .= "X-Sender: $SiteEmail \r\n";
            $headers .= "X-Priority: 3 \r\n";
            $headers .= "X-Mailer: php\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            //mail($mail_to, $mail_subject, $mail_body, $headers);
            echo $mail_to, $mail_subject, $mail_body, $headers;
        endforeach;
    
    endif;
    
    
} catch (PDOException $ex) {
    //ONLY echo error message during development to test for problems
    //echo  $ex->getMessage();
}
?>
