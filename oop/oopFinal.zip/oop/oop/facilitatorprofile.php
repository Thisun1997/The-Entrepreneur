<?php 
	require_once 'core/init.php';
    $user = new Facilitator();
    
    if((time()-$_SESSION['last_time'])>3600):
      $user->logout();
      
      Session::flash('success','<div class="alert alert-danger">
                    Sorry!. Session timeout. please log in and try again.
                  </div>');
        Redirect::to('index.php#register-login');
    else:
        $email = $user->data()->email;
      $_SESSION['last_time'] = time();
      if(isset($_POST["edit"])){
        Redirect::to("facilitatoredit.php");
      }
      elseif(isset($_POST["changepass"])){
        Redirect::to("changepassword.php");
      }
      elseif(isset($_POST["viewpost"])){
        Redirect::to("viewPost.php");
      }
      elseif(isset($_POST["delete"])){
        Redirect::to("delete.php");
      }if(isset($_POST['comment'])){
        Comment::createComment($_POST['body'],$_POST['postid'],$email);
}
      
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Facilitator account</title>
  <meta charset="utf-8">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/profile.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="http://use.fontawesome.com/d1341f9b7a.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" rel="stylesheet">
   <style>
   .timelineposts a,.accepted a{
           color:#4388A5;
   }

   </style>

</head>
<body>

<div class="modal fade" id="commentsmodal" role="dialog" tabindex="-1" style="padding-top:100px;">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
                                            <h4 class="modal-title">Comments</h4></div>
                                        <div class="modal-body" style="max-height: 400px; overflow-y: auto">
                                            <p>The content of your modal.</p>
                                        </div>
                                        <div class="modal-footer">
                                                <form action=""method="post">
                                                        <textarea name="body"rows="3"  cols="70"></textarea>
                                                        <input type="hidden" name="postid" id="postid">
                                                        <button class="btn btn-primary"  type="submit" name="comment">Comment</button>
                                                        
                                                </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

<div class="conatiner">
  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="mi-modal">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Do youy really want to logout?</h4>
        </div>
        <div class="modal-footer">
          <a href = "logout.php"><button type="button" class="btn btn-default" id="modal-btn-si">Yes</button></a>
          <a href = "index.php"><button type="button" class="btn btn-primary" id="modal-btn-no">No</button></a>
        </div>
      </div>
    </div>
  </div>
</div>


  <div class="container-fluid">
    <div class="row heading">
      <div class="container">
        <div class="col-md-3 col-sm-6">
          <img src="img/best.png">
        </div>
      </div>
    </div>

  <div class="row">
  <br>
  <?php if(Session::exists('edit')){
            echo Session::flash('edit');
          } ?>


      <div class="col-md-4">
          <div class="box">
          <img id="profile" src="img/img_avatar.png" alt="Avatar">
          <h1><?php echo escape($user->data()->firstname)." ".escape($user->data()->lastname); ?></h2>
                <h3></h1>
          <h3>Facilitator</h3>
          <br>     
          <div class ="main-container">
                  <p>I am interested in <strong><?php echo escape($user->data()->categories); ?><strong></p>
                  
                  <p><i class="fa fa-home info"></i>    <?php echo escape($user->data()->address); ?></p>
                  
                  <p><i class="fa fa-envelope info"></i> <?php echo escape($user->data()->email); ?></p>
                  
                  <p><i class="fa fa-phone info"></i> <?php echo escape($user->data()->phonenumber); ?></p>

                  
                  <div class="bio">
                  <p><?php echo "\" ".escape($user->data()->bio)." \"" ?></p></div>
          </div>
          </div>          
      </div>
      <div class="col-md-8">
        <div class="row">
        <form method="post">
            <button style = "margin-top:10px!important" type="submit" name="edit"><i class="fas fa-user-edit"></i>  Edit account</button>
            <button style = "margin-top:10px!important" type="submit" name="changepass"><i class="fas fa-key"></i>  Edit password</button>
            <button style = "margin-top:10px!important" type="submit" name="viewpost"><i class="fas fa-eye"></i>  View posts</button>
            <button style = "margin-top:10px!important" type="submit" name="delete"><i class="fas fa-user-slash"></i>  Delete account</button>
        </form>
        <button style = "margin-top:10px!important" name="logout" id="btn-confirm" style="margin-top:10px"><i class="fas fa-sign-out-alt"></i> logout</button>
      </div>
        <div class="row">
          <div class="container tabs">
            <h2>What I have done</h2>
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#home">Posts I have given offers</a></li>
              <li><a data-toggle="tab" href="#menu2">Posts I have set flags</a></li>
            </ul>
            <div class="tab-content">
              <div id="home" class="tab-pane fade in active">
                <div class="timelineposts">
                </div>
              </div>
              <div id="menu1" class="tab-pane fade">
              
              </div>
              <div id="menu2" class="tab-pane fade">
              <div class="accepted">
                </div>
              </div>
            </div>
          </div>  
          <div>  
  </div>
</div>
</div>

<script>
    function fun(){
    window.alert("Succssfully logged out.");
  }

  var modalConfirm = function(callback){
  
  $("#btn-confirm").on("click", function(){
    $("#mi-modal").modal('show');
  });

  $("#modal-btn-si").on("click", function(){
    callback(true);
    $("#mi-modal").modal('hide');
  });
  
  $("#modal-btn-no").on("click", function(){
    callback(false);
    $("#mi-modal").modal('hide');
  });
};

modalConfirm(function(confirm){
  if(confirm){
    
  }else{
    
  }
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
    <script type="text/javascript">
    var start = 5;
    var working = false;
    $(window).scroll(function() {
            if ($(this).scrollTop() + 1 >= $('body').height() - $(window).height()) {
                    if (working == false) {
                            working = true;
                            $.ajax({
                                    type: "GET",
                                    url: "api/profilepostsfaci?email=<?php echo $email ?>&start="+start,
                                    processData: false,
                                    contentType: "application/json",
                                    data: '',
                                    success: function(r) {
                                            var posts = JSON.parse(r)
                                            $.each(posts, function(index) {
                                                if (posts[index].PostImage == "" && posts[index].PostVideo != "") {
                                                $('.timelineposts').html(
                                                        $('.timelineposts').html() +
                                                        '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video: <a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'</footer></blockquote></li>'
                                                )
                                                } else if (posts[index].PostImage != "" && posts[index].PostVideo == ""){
                                                        $('.timelineposts').html(
                                                                $('.timelineposts').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><img src="" style="height:20%"data-tempsrc="'+posts[index].PostImage+'" class="postimg" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'</footer></blockquote></li>'                                                        )
                                                }else {
                                                        $('.timelineposts').html(
                                                                $('.timelineposts').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><img src="" data-tempsrc="'+posts[index].PostImage+'" class="postimg" style="opacity: 0;transition: all 2s ease-out;width:100%;" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'</footer></blockquote></li>'                                                        )
                                                }
                                                    $('[data-postid]').click(function() {
                                                            var buttonid = $(this).attr('data-postid');
                                                            $.ajax({
                                                                    type: "GET",
                                                                    url: "api/comments?postid=" + $(this).attr('data-postid'),
                                                                    processData: false,
                                                                    contentType: "application/json",
                                                                    data: '',
                                                                    success: function(r) {
                                                                            var res = JSON.parse(r)
                                                                            showCommentsModal(res,buttonid);
                                                                    },
                                                                    error: function(r) {
                                                                            console.log(r)
                                                                    }
                                                            });
                                                    });
                                                    $('[data-id]').click(function() {
                                                            var buttonid = $(this).attr('data-id');
                                                            $.ajax({
                                                                    type: "POST",
                                                                    url: "api/likes?id=" + $(this).attr('data-id'),
                                                                    processData: false,
                                                                    contentType: "application/json",
                                                                    data: '',
                                                                    success: function(r) {
                                                                            var res = JSON.parse(r)
                                                                            $("[data-id='"+buttonid+"']").html(' <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+res.Flags+' Flags</span>')
                                                                    },
                                                                    error: function(r) {
                                                                            console.log(r)
                                                                    }
                                                            });
                                                    })
                                            })
                                            $('.postimg').each(function() {
                                                    this.src=$(this).attr('data-tempsrc')
                                                    this.onload = function() {
                                                        this.style.opacity = '1';
                                                        this.style.width = '80%';
                                                        this.style.height = '10%';
                                                    }
                                            })
                                            scrollToAnchor(location.hash)
                                            start+=5;
                                            setTimeout(function() {
                                                    working = false;
                                            }, 4000)
                                    },
                                    error: function(r) {
                                            console.log(r)
                                    }
                            });
                            $.ajax({
                                    type: "GET",
                                    url: "api/profilepostsflagged?email=<?php echo $email ?>&start="+start,
                                    processData: false,
                                    contentType: "application/json",
                                    data: '',
                                    success: function(r) {
                                            var posts = JSON.parse(r)
                                            $.each(posts, function(index) {
                                                if (posts[index].PostImage == "" && posts[index].PostVideo != "") {
                                                  $('.accepted').html(
                                                        $('.accepted').html() +
                                                        '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments '+posts[index].Com+'</span></button></footer></blockquote></li>'
                                                )
                                                } else if (posts[index].PostImage != "" && posts[index].PostVideo == ""){
                                                        $('.accepted').html(
                                                                $('.accepted').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><img src="" style="height:20%"data-tempsrc="'+posts[index].PostImage+'" class="postimg" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments '+posts[index].Com+'</span></button></footer></blockquote></li>'
                                                        )
                                                }else {
                                                        $('.accepted').html(
                                                                $('.accepted').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><img src="" data-tempsrc="'+posts[index].PostImage+'" class="postimg" style="opacity: 0;transition: all 2s ease-out;width:100%;" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments '+posts[index].Com+'</span></button></footer></blockquote></li>'
                                                        )
                                                }
                                                    $('[data-postid]').click(function() {
                                                            var buttonid = $(this).attr('data-postid');
                                                            $.ajax({
                                                                    type: "GET",
                                                                    url: "api/comments?postid=" + $(this).attr('data-postid'),
                                                                    processData: false,
                                                                    contentType: "application/json",
                                                                    data: '',
                                                                    success: function(r) {
                                                                            var res = JSON.parse(r)
                                                                            showCommentsModal(res,buttonid);
                                                                    },
                                                                    error: function(r) {
                                                                            console.log(r)
                                                                    }
                                                            });
                                                    });
                                                    $('[data-id]').click(function() {
                                                            var buttonid = $(this).attr('data-id');
                                                            $.ajax({
                                                                    type: "POST",
                                                                    url: "api/likes?id=" + $(this).attr('data-id'),
                                                                    processData: false,
                                                                    contentType: "application/json",
                                                                    data: '',
                                                                    success: function(r) {
                                                                            var res = JSON.parse(r)
                                                                            $("[data-id='"+buttonid+"']").html(' <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+res.Flags+' Flags</span>')
                                                                    },
                                                                    error: function(r) {
                                                                            console.log(r)
                                                                    }
                                                            });
                                                    })
                                            })
                                            $('.postimg').each(function() {
                                                    this.src=$(this).attr('data-tempsrc')
                                                    this.onload = function() {
                                                        this.style.opacity = '1';
                                                        this.style.width = '80%';
                                                        this.style.height = '10%';
                                                    }
                                            })
                                            scrollToAnchor(location.hash)
                                            start+=5;
                                            setTimeout(function() {
                                                    working = false;
                                            }, 4000)
                                    },
                                    error: function(r) {
                                            console.log(r)
                                    }
                            });
                    }
            }
    })
    function scrollToAnchor(aid){
    try {
    var aTag = $(aid);
        $('html,body').animate({scrollTop: aTag.offset().top},'slow');
        } catch (error) {
                console.log(error)
        }
    }
        $(document).ready(function() {
                $.ajax({
                        type: "GET",
                        url: "api/profilepostsfaci?email=<?php echo $email; ?>&start=0",
                        processData: false,
                        contentType: "application/json",
                        data: '',
                        success: function(r) {
                                var posts = JSON.parse(r)
                                $.each(posts, function(index) {
                                        if (posts[index].PostImage == "" && posts[index].PostVideo != "") {
                                          $('.timelineposts').html(
                                                        $('.timelineposts').html() +
                                                        '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'</footer></blockquote></li>'
                                                )
                                                } else if (posts[index].PostImage != "" && posts[index].PostVideo == ""){
                                                        $('.timelineposts').html(
                                                                $('.timelineposts').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><img src="" style="height:20%"data-tempsrc="'+posts[index].PostImage+'" class="postimg" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'</footer></blockquote></li>'                                                        )
                                                }else {
                                                        $('.timelineposts').html(
                                                                $('.timelineposts').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><img src="" data-tempsrc="'+posts[index].PostImage+'" class="postimg" style="opacity: 0;transition: all 2s ease-out;width:100%;" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'</footer></blockquote></li>'
                                                        )
                                                }
                                        $('[data-postid]').click(function() {
                                                var buttonid = $(this).attr('data-postid');
                                                $.ajax({
                                                        type: "GET",
                                                        url: "api/comments?postid=" + $(this).attr('data-postid'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                showCommentsModal(res,buttonid);
                                                        },
                                                        error: function(r) {
                                                                console.log(r)
                                                        }
                                                });
                                        });
                                        $('[data-id]').click(function() {
                                                var buttonid = $(this).attr('data-id');
                                                $.ajax({
                                                        type: "POST",
                                                        url: "api/likes?id=" + $(this).attr('data-id'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                $("[data-id='"+buttonid+"']").html(' <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+res.Flags+' Flags</span>')
                                                        },
                                                        error: function(r) {
                                                                console.log(r)
                                                        }
                                                });
                                        })

                                })
                                $('.postimg').each(function() {
                                        this.src=$(this).attr('data-tempsrc')
                                        this.onload = function() {
                                                this.style.opacity = '1';
                                                this.style.width = '80%';
                                                this.style.height = '10%';
                                                
                                                
                                        }
                                })
                                scrollToAnchor(location.hash)
                        },
                        error: function(r) {
                                console.log(r)
                        }
                });
                $.ajax({
                        type: "GET",
                        url: "api/profilepostsflagged?email=<?php echo $email; ?>&start=0",
                        processData: false,
                        contentType: "application/json",
                        data: '',
                        success: function(r) {
                                var posts = JSON.parse(r)
                                $.each(posts, function(index) {
                                        if (posts[index].PostImage == "" && posts[index].PostVideo != "") {
                                          $('.accepted').html(
                                                        $('.accepted').html() +
                                                        '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments '+posts[index].Com+'</span></button></footer></blockquote></li>'
                                                )
                                                } else if (posts[index].PostImage != "" && posts[index].PostVideo == ""){
                                                        $('.accepted').html(
                                                                $('.accepted').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><img src="" style="height:20%"data-tempsrc="'+posts[index].PostImage+'" class="postimg" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments '+posts[index].Com+'</span></button></footer></blockquote></li>'
                                                        )
                                                }else {
                                                        $('.accepted').html(
                                                                $('.accepted').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><img src="" data-tempsrc="'+posts[index].PostImage+'" class="postimg" style="opacity: 0;transition: all 2s ease-out;width:100%;" id="img'+posts[index].postId+'"><footer>Posted by <a href=visitInventor.php?user='+posts[index].PostEmail+'>'+posts[index].PostedBy+' </a> on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments '+posts[index].Com+'</span></button></footer></blockquote></li>'
                                                        )
                                                }
                                        $('[data-postid]').click(function() {
                                                var buttonid = $(this).attr('data-postid');
                                                $.ajax({
                                                        type: "GET",
                                                        url: "api/comments?postid=" + $(this).attr('data-postid'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                showCommentsModal(res,buttonid);
                                                        },
                                                        error: function(r) {
                                                                console.log(r)
                                                        }
                                                });
                                        });
                                        $('[data-id]').click(function() {
                                                var buttonid = $(this).attr('data-id');
                                                $.ajax({
                                                        type: "POST",
                                                        url: "api/likes?id=" + $(this).attr('data-id'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                $("[data-id='"+buttonid+"']").html(' <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+res.Flags+' Flags</span>')
                                                        },
                                                        error: function(r) {
                                                                console.log(r)
                                                        }
                                                });
                                        })
                                })
                                $('.postimg').each(function() {
                                        this.src=$(this).attr('data-tempsrc')
                                        this.onload = function() {
                                                this.style.opacity = '1';
                                                this.style.width = '80%';
                                                this.style.height = '10%';
                                                
                                                
                                        }
                                })
                                scrollToAnchor(location.hash)
                        },
                        error: function(r) {
                                console.log(r)
                        }
                });
        });
        function showCommentsModal(res,buttonid) {
                $('#commentsmodal').modal('show')
                var output = "";
                for (var i = 0; i < res.length; i++) {
                        output += res[i].CommentedBy;
                        output += " ~ ";
                        output += res[i].Comment;
                        if (output == "undefined ~ undefined"){
                                output = "no comments"
                        }
                        output += "<hr />";
                        
                }
                $('.modal-body').html(output)
                $('.modal-footer #postid').val(buttonid);
        }
    </script>




</body>
</html>

<?php endif ?>