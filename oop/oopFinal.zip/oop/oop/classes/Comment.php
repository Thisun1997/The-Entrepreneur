<?php
    class Comment{
        public static function createComment($commentBody,$postId,$email){
            $db = DB::getInstance();
            if (strlen($commentBody)>160 || strlen($commentBody)<1) {
                die('Incorrect length');
            }
            if (!$db->query2('SELECT id FROM posts WHERE id=:postid',array(':postid'=>$postId))) {
                echo 'Invalid post ID';
            }else {
                $db->query2('INSERT INTO comments(comment,email,posted_at,post_id) VALUES(:comment,:email,NOW(),:postid)',array(':comment'=>$commentBody,':email'=>$email,':postid'=>$postId));
                $db->query2('UPDATE posts SET no_comments=no_comments+1 WHERE id=:postid', array(':postid'=>$postId));
            }
        }

        // public static function displayPosts($postId){
        //     $comments = $db->query2('SELECT comments.comment,facilitators.firstname FROM comments,facilitators WHERE post_id =:postid AND comments.email = email',array(':postid'=>$postId));
        //     foreach ($comments as $comment ) {
        //         echo $comment['comment'].'~'.$comment['username'].'<hr />';
        //     }
        // }
    }
?>