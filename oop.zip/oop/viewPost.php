<?php
        require_once 'core/init.php';
        $user = new Facilitator();
        $email = $user->data()->email;
        if(isset($_POST['comment'])){
                Comment::createComment($_POST['body'],$_POST['postid'],$email);
        }
?>

<!DOCTYPE html>
<head>
  <title>Posts</title>
  <meta charset="utf-8">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="http://use.fontawesome.com/d1341f9b7a.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" rel="stylesheet">
</head>
<body>

                <div class="modal fade" id="commentsmodal" role="dialog" tabindex="-1" style="padding-top:100px;">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
                                            <h4 class="modal-title">Comments</h4></div>
                                        <div class="modal-body" style="max-height: 400px; overflow-y: auto">
                                            <p>The content of your modal.</p>
                                        </div>
                                        <div class="modal-footer">
                                                <form action=""method="post">
                                                        <textarea name="body"rows="3"  cols="75"></textarea>
                                                        <input type="hidden" name="postid" id="postid">
                                                        <button class="btn btn-primary"  type="submit" name="comment">Comment</button>
                                                        
                                                </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
<div class="container">
        <h1>Timeline </h1>
        <div class="timelineposts">

        </div>
    </div>
    <script type="text/javascript">

        $(document).ready(function() {

                $('.sbox').keyup(function() {
                        $('.autocomplete').html("")
                        $.ajax({

                                type: "GET",
                                url: "api/search?query=" + $(this).val(),
                                processData: false,
                                contentType: "application/json",
                                data: '',
                                success: function(r) {
                                        r = JSON.parse(r)
                                        for (var i = 0; i < r.length; i++) {
                                                console.log(r[i].body)
                                                $('.autocomplete').html(
                                                        $('.autocomplete').html() +
                                                        '<a href="profile.php?username='+r[i].username+'#'+r[i].id+'"><li class="list-group-item"><span>'+r[i].body+'</span></li>'
                                                )
                                        }
                                },
                                error: function(r) {
                                        console.log(r)
                                }
                        })
                })

                $.ajax({

                        type: "GET",
                        url: "api/posts",
                        processData: false,
                        contentType: "application/json",
                        data: '',
                        success: function(r) {
                                var posts = JSON.parse(r)
                                $.each(posts, function(index) {
                                    if (posts[index].PostImage == "" && posts[index].PostVideo != "") {
                                                $('.timelineposts').html(
                                                        $('.timelineposts').html() +
                                                        '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><footer>Posted by '+posts[index].PostedBy+' on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;" ></i><span style="color:#f9d616;"> Comments</span></button></footer></blockquote></li>'
                                                )
                                                } else if (posts[index].PostImage != "" && posts[index].PostVideo == ""){
                                                        $('.timelineposts').html(
                                                                $('.timelineposts').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><img src="" style="height:20%"data-tempsrc="'+posts[index].PostImage+'" class="postimg" id="img'+posts[index].postId+'"><footer>Posted by '+posts[index].PostedBy+' on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" ><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments</span></button></footer></blockquote></li>'
                                                        )
                                                }else {
                                                        $('.timelineposts').html(
                                                                $('.timelineposts').html() +
                                                                '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><p style="color:grey">'+posts[index].Categories+'</p><p>Checkout the video:<a href="'+posts[index].PostVideo+'">'+posts[index].PostVideo+'</a></p><img src="" data-tempsrc="'+posts[index].PostImage+'" class="postimg" style="opacity: 0;transition: all 2s ease-out;width:100%;" id="img'+posts[index].postId+'"><footer>Posted by '+posts[index].PostedBy+' on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Flags+' Flags</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments</span></button></footer></blockquote></li>'
                                                        )
                                                }
                                        $('[data-postid]').click(function() {
                                                var buttonid = $(this).attr('data-postid');

                                                $.ajax({

                                                        type: "GET",
                                                        url: "api/comments?postid=" + $(this).attr('data-postid'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                showCommentsModal(res,buttonid);
                                                        },
                                                        error: function(r) {
                                                                showCommentsModal1();
                                                        }

                                                });
                                        });

                                        $('[data-id]').click(function() {
                                                var buttonid = $(this).attr('data-id');
                                                $.ajax({

                                                        type: "POST",
                                                        url: "api/likes?id=" + $(this).attr('data-id'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                $("[data-id='"+buttonid+"']").html(' <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+res.Flags+' Flags</span>')
                                                        },
                                                        error: function(r) {
                                                                console.log(r)
                                                        }

                                                });
                                        })
                                })
                                $('.postimg').each(function() {
                                                    this.src=$(this).attr('data-tempsrc')
                                                    this.onload = function() {
                                                        this.style.opacity = '1';
                                                        this.style.width = '80%';
                                                        this.style.height = '10%';
                                                        this.style.margin =  '10px';
                                                    }
                                            })

                        },
                        error: function(r) {
                                console.log(r)
                        }

                });

        });

        function showCommentsModal(res,buttonid) {
                $('.modal').modal('show')
                var output = "";
                for (var i = 0; i < res.length; i++) {
                        output += res[i].CommentedBy;
                        output += " ~ ";
                        output += res[i].Comment;
                        if (output == "undefined ~ undefined"){
                                output = "no comments"
                        }
                        output += "<hr />";
                }

                $('.modal-body').html(output)
                $('.modal-footer #postid').val(buttonid);
        }
        
        

    </script>
</body>
</html>


