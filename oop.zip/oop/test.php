<?php
echo 'abc';
?>