<?php

require_once 'core/init.php';

$user = new Facilitator;

$user->sendMessage();


?>