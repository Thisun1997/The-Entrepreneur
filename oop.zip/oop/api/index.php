<?php
require_once 'core/init.php';
require_once("Mail.php");
$user = new Inventor(Input::get('user'));
echo Input::get('user');
//$db = new DB("127.0.0.1", "SocialNetwork", "root", "");
$db = DB::getInstance();
if ($_SERVER['REQUEST_METHOD'] == "GET") {

        if ($_GET['url'] == "musers"){

                $token = $_COOKIE['SNID'];
                $userid = $db->query2('SELECT user_id FROM login_tokens WHERE token=:token', array(':token'=>sha1($token)))[0]['user_id'];
                $users = $db->query2("SELECT DISTINCT s.username AS Sender, r.username AS Receiver, s.id AS SenderID, r.id AS ReceiverID FROM messages LEFT JOIN users s ON s.id = messages.sender LEFT JOIN users r ON r.id = messages.receiver WHERE (s.id = :userid OR r.id=:userid)", array(":userid"=>$userid));
                $u = array();
                foreach ($users as $user) {
                        if (!in_array(array('username'=>$user['Receiver'], 'id'=>$user['ReceiverID']), $u)) {
                                array_push($u, array('username'=>$user['Receiver'], 'id'=>$user['ReceiverID']));
                        }
                        if (!in_array(array('username'=>$user['Sender'], 'id'=>$user['SenderID']), $u)) {
                                array_push($u, array('username'=>$user['Sender'], 'id'=>$user['SenderID']));
                        }
                }
                echo json_encode($u);

        } else if ($_GET['url'] == "auth") {

        } else if ($_GET['url'] == "messages") {
                $sender = $_GET['sender'];
                $token = $_COOKIE['SNID'];
                $receiver = $db->query('SELECT user_id FROM login_tokens WHERE token=:token', array(':token'=>sha1($token)))[0]['user_id'];
                $messages = $db->query('SELECT messages.id, messages.body, s.username AS Sender, r.username AS Receiver
                FROM messages
                LEFT JOIN users s ON messages.sender = s.id
                LEFT JOIN users r ON messages.receiver = r.id
                WHERE (r.id=:r AND s.id=:s) OR r.id=:s AND s.id=:r', array(':r'=>$receiver, ':s'=>$sender));
                echo json_encode($messages);

        } else if ($_GET['url'] == "search") {

                $tosearch = explode(" ",$_GET['query']);
                if (count($tosearch) == 1 ) {
                        $tosearch = str_split($tosearch[0], 2);
                }

                $whereclause = "";
                $paramsarray = array(':body'=>'%'.$_GET['query'].'%');

                for ($i=0; $i < count($tosearch); $i++) { 
                        if($i % 2){
                                $whereclause .= " OR body LIKE :p$i";
                                $paramsarray[":p$i"] = $tosearch[$i];
                        }
                }

                $posts = $db->query('SELECT posts.id,posts.body,users.username,posts.posted_at FROM posts,users WHERE users.id = posts.user_id AND posts.body LIKE :body '.$whereclause.'LIMIT 10', $paramsarray);
                //echo "<pre>";
                echo json_encode($posts);
                //echo "</pre>";

        } else if ($_GET['url'] == "users") {
                $token = $_COOKIE['SNID'];
                $user_id = $db->query('SELECT user_id fROM login_tokens WHERE token=:token',array(':token'=>sha1($token)))[0]['user_id'];
                $username = $db->query('SELECT username FROM users WHERE id=:uid',array(':uid'=>$user_id))[0]['username'];
                echo $username;

        } else if ($_GET['url'] == "comments" && isset($_GET['postid'])) {
                $output = "";
                $comments = $db->query2('SELECT comments.comment,comments.email,facilitators.firstname FROM comments,facilitators WHERE post_id =:postid AND comments.email = facilitators.email',array(':postid'=>$_GET['postid']));
                $output .= "[";
                foreach ($comments as $comment ) {
                        $output .= "{";
                        $output .= '"Comment":"'.$comment['comment'].'",';
                        $output .= '"CommentEmail":"'.$comment['email'].'",';
                        $output .= '"CommentedBy":"'.$comment['firstname'].'"';
                        $output .= "},";
                        //echo $comment['comment'].'~'.$comment['username'].'<hr />';
                }
                if($output != "["){
                        $output = substr($output,0,strlen($output)-1);
                        $output .= "]";
                        echo $output;
                }else{
                        $output = "[{}]";
                        echo $output;
                }

        } else if ($_GET['url'] == "posts") {
                //$token = $_COOKIE['SNID'];
                //$userid = $db->query('SELECT user_id fROM login_tokens WHERE token=:token',array(':token'=>sha1($token)))[0]['user_id'];

                $posts = $db->query2('SELECT posts.id, posts.no_comments,posts.body,posts.posted_at,posts.postimg ,posts.flags, posts.categories, posts.postvideo ,posts.firstname,posts.email FROM posts
                WHERE posts.accepted = 0
                ORDER BY posts.flags DESC',array());

                $response = "[";
                foreach($posts as $post) {

                        $response .= "{";
                                $response .= '"PostId": '.$post['id'].',';
                                $response .= '"PostBody": "'.$post['body'].'",';
                                $response .= '"PostedBy": "'.$post['firstname'].'",';
                                $response .= '"PostedByEmail": "'.$post['email'].'",';
                                $response .= '"PostDate": "'.$post['posted_at'].'",';
                                $response .= '"PostImage": "'.$post['postimg'].'",';
                                $response .= '"PostVideo": "'.$post['postvideo'].'",';
                                $response .= '"Flags": '.$post['flags'].',';
                                $response .= '"Com": '.$post['no_comments'].',';
                                $response .= '"Categories": "'.$post['categories'].'"';
                        $response .= "},";

                }
             
                $response = substr($response,0,strlen($response)-1);
                $response .= "]";
                echo $response;

        }else if ($_GET['url'] == "profileposts") { 
                $start = (int)$_GET['start']; //infinite scroll posts api
                //$user = $db->query('SELECT id fROM users WHERE username=:username',array(':username'=>$_GET['username']))[0]['id'];
                $email = $_GET['email'];
                $followingposts = $db->query2('SELECT posts.id, posts.no_comments,posts.body,posts.posted_at,posts.postimg ,posts.flags, posts.categories, posts.postvideo, inventor.`firstname` FROM inventor, posts
                WHERE inventor.email = posts.email
                AND inventor.email =:email
                AND posts.accepted = 0
                ORDER BY posts.posted_at DESC
                LIMIT 5
                OFFSET '.$start.';',array(':email'=>$email));
                $response = "[";
                foreach($followingposts as $post) {

                        $response .= "{";
                                $response .= '"PostId": '.$post['id'].',';
                                $response .= '"PostBody": "'.$post['body'].'",';
                                $response .= '"PostedBy": "'.$post['firstname'].'",';
                                $response .= '"PostDate": "'.$post['posted_at'].'",';
                                $response .= '"PostImage": "'.$post['postimg'].'",';
                                $response .= '"PostVideo": "'.$post['postvideo'].'",';
                                $response .= '"Flags": '.$post['flags'].',';
                                $response .= '"Com": '.$post['no_comments'].',';
                                $response .= '"Categories": "'.$post['categories'].'"';
                        $response .= "},";

                }
                $response = substr($response,0,strlen($response)-1);
                $response .= "]";
                echo $response;
        }
        else if ($_GET['url'] == "profilepostsaccepted") { 
                $start = (int)$_GET['start']; //infinite scroll posts api
                //$user = $db->query('SELECT id fROM users WHERE username=:username',array(':username'=>$_GET['username']))[0]['id'];
                $email = $_GET['email'];
                $followingposts = $db->query2('SELECT posts.id, posts.body,posts.posted_at,posts.postimg ,posts.flags, posts.categories, posts.postvideo,posts.accepted_name,  inventor.`firstname` FROM  inventor,posts
                WHERE inventor.email = posts.email
                AND inventor.email =:email
                AND posts.accepted = 1
                ORDER BY posts.posted_at DESC
                LIMIT 5
                OFFSET '.$start.';',array(':email'=>$email));
                $response = "[";
                foreach($followingposts as $post) {

                        $response .= "{";
                                $response .= '"PostId": '.$post['id'].',';
                                $response .= '"PostBody": "'.$post['body'].'",';
                                $response .= '"PostedBy": "'.$post['firstname'].'",';
                                $response .= '"PostDate": "'.$post['posted_at'].'",';
                                $response .= '"PostAccepted": "'.$post['accepted_name'].'",';
                                $response .= '"PostImage": "'.$post['postimg'].'",';
                                $response .= '"PostVideo": "'.$post['postvideo'].'",';
                                $response .= '"Flags": '.$post['flags'].',';
                                $response .= '"Categories": "'.$post['categories'].'"';
                        $response .= "},";

                }
                $response = substr($response,0,strlen($response)-1);
                $response .= "]";
                echo $response;
        }else if ($_GET['url'] == "profilepostsfaci") { 
                $start = (int)$_GET['start']; //infinite scroll posts api
                //$user = $db->query('SELECT id fROM users WHERE username=:username',array(':username'=>$_GET['username']))[0]['id'];
                $email = $_GET['email'];
                $followingposts = $db->query2('SELECT posts.id, posts.email,posts.body,posts.posted_at,posts.postimg ,posts.flags, posts.categories, posts.postvideo,posts.accepted_name,posts.firstname FROM posts
                WHERE posts.accepted_by = :email
                AND posts.accepted = 1
                ORDER BY posts.posted_at DESC
                LIMIT 5
                OFFSET '.$start.';',array(':email'=>$email));
                $response = "[";
                foreach($followingposts as $post) {

                        $response .= "{";
                                $response .= '"PostId": '.$post['id'].',';
                                $response .= '"PostBody": "'.$post['body'].'",';
                                $response .= '"PostedBy": "'.$post['firstname'].'",';
                                $response .= '"PostDate": "'.$post['posted_at'].'",';
                                $response .= '"PostEmail": "'.$post['email'].'",';
                                $response .= '"PostAccepted": "'.$post['accepted_name'].'",';
                                $response .= '"PostImage": "'.$post['postimg'].'",';
                                $response .= '"PostVideo": "'.$post['postvideo'].'",';
                                $response .= '"Flags": '.$post['flags'].',';
                                $response .= '"Categories": "'.$post['categories'].'"';
                        $response .= "},";

                }
                $response = substr($response,0,strlen($response)-1);
                $response .= "]";
                echo $response;
        }else if ($_GET['url'] == "profilepostsflagged") { 
                $start = (int)$_GET['start']; //infinite scroll posts api
                //$user = $db->query('SELECT id fROM users WHERE username=:username',array(':username'=>$_GET['username']))[0]['id'];
                $email = $_GET['email'];
                $followingposts = $db->query2('SELECT posts.id, posts.no_comments,posts.email,posts.body,posts.posted_at,posts.postimg ,posts.flags, posts.categories, posts.postvideo,posts.accepted_name,posts.firstname FROM posts,post_flag
                WHERE posts.id = post_flag.post_id
                AND post_flag.email = :email
                AND posts.accepted = 0
                ORDER BY posts.posted_at DESC
                LIMIT 5
                OFFSET '.$start.';',array(':email'=>$email));
                $response = "[";
                foreach($followingposts as $post) {

                        $response .= "{";
                                $response .= '"PostId": '.$post['id'].',';
                                $response .= '"PostBody": "'.$post['body'].'",';
                                $response .= '"PostedBy": "'.$post['firstname'].'",';
                                $response .= '"PostDate": "'.$post['posted_at'].'",';
                                $response .= '"PostEmail": "'.$post['email'].'",';
                                $response .= '"PostAccepted": "'.$post['accepted_name'].'",';
                                $response .= '"PostImage": "'.$post['postimg'].'",';
                                $response .= '"PostVideo": "'.$post['postvideo'].'",';
                                $response .= '"Flags": '.$post['flags'].',';
                                $response .= '"Com": '.$post['no_comments'].',';
                                $response .= '"Categories": "'.$post['categories'].'"';
                        $response .= "},";

                }
                $response = substr($response,0,strlen($response)-1);
                $response .= "]";
                echo $response;
        }

} else if ($_SERVER['REQUEST_METHOD'] == "POST") {

        

        if ($_GET['url'] == "message"){
                //$token = $_COOKIE['SNID'];
        $userid = $db->query('SELECT user_id FROM login_tokens WHERE token=:token', array(':token'=>sha1($token)))[0]['user_id'];
        $postBody = file_get_contents("php://input");
        $postBody = json_decode($postBody);
        $body = $postBody->body;
        $receiver = $postBody->receiver;
        if (strlen($body) > 100) {
                echo "{ 'Error': 'Message too long!' }";
        }
        $db->query("INSERT INTO messages VALUES ('', :body, :sender, :receiver, '0')", array(':body'=>$body, ':sender'=>$userid, ':receiver'=>$receiver));
        echo '{ "Success": "Message Sent!" }';

        } else if ($_GET['url'] == "users"){
                $postBody = file_get_contents("php://input");
                $postBody = json_decode($postBody);

                $username = $postBody->username;
                $email = $postBody->email;
                $password = $postBody->password;

                if(!$db->query('SELECT username FROM users WHERE username=:username',array(':username'=>$username))){
			if (strlen($username) >= 3 && strlen($username) <= 32){
				if(preg_match('/[a-zA-Z0-9_]+/', $username)){
					if(strlen($password) >= 6 && strlen($password) <= 60){
						if(filter_var($email, FILTER_VALIDATE_EMAIL)){
							if(!$db->query('SELECT email FROM users WHERE email=:email',array(':email'=>$email))){
								$db->query('INSERT INTO users (username,password,email,verified) VALUES (:username,:password,:email,\'0\')',array(':username'=>$username,':password'=>password_hash($password,PASSWORD_BCRYPT),'email'=>$email));
								Mail::sendMail('Welcome to our Social Network','Your account has been created',$email);
                                                                echo '{ "Success": "User Created!" }';
                                                                http_response_code(200);
                                
							}else{
                                                                echo '{ "Error": "Email in Use!" }';
                                                                http_response_code(409);
                                
							}
						}else {
                                                        echo '{ "Error": "Invalid Email!" }';
                                                        http_response_code(409);
                        
						}
					}else {
                                                echo '{ "Error": "Invalid Password!" }';
                                                http_response_code(409);
                
					}
				}else {
                                        echo '{ "Error": "Invalid Username!" }';
                                        http_response_code(409);
        
				}
			}else {
				echo '{ "Error": "Invalid Username!" }';
                                http_response_code(409);
			}
		}else{
                        echo '{ "Error": "User Exists!" }';
                        http_response_code(409);
		}
        }

        if ($_GET['url'] == "auth") {
                $postBody = file_get_contents("php://input");
                $postBody = json_decode($postBody);

                $username = $postBody->username;
                $password = $postBody->password;

                if ($db->query('SELECT username FROM users WHERE username=:username', array(':username'=>$username))) {
                        if (password_verify($password, $db->query('SELECT password FROM users WHERE username=:username', array(':username'=>$username))[0]['password'])) {
                                $cstrong = True;
                                $token = bin2hex(openssl_random_pseudo_bytes(64, $cstrong));
                                $user_id = $db->query('SELECT id FROM users WHERE username=:username', array(':username'=>$username))[0]['id'];
                                $db->query('INSERT INTO login_tokens(token,user_id) VALUES (:token, :user_id)', array(':token'=>sha1($token), ':user_id'=>$user_id));
                                echo '{ "Token": "'.$token.'" }';
                        } else {
                                echo '{ "Error": "Invalid username or password!" }';
                                http_response_code(401);
                        }
                } else {
                        echo '{ "Error": "Invalid username or password!" }';
                        http_response_code(401);
                }

        }else if ($_GET['url'] == "likes") {

                $postId = $_GET['id'];
          
               // $token = $_COOKIE['SNID'];
               $email = $user->data()->email;
                //$likerId = $db->query('SELECT user_id fROM login_tokens WHERE token=:token',array(':token'=>sha1($token)))[0]['user_id'];

                if (!$db->query2('SELECT email FROM post_flag WHERE post_id=:postid AND email=:email', array(':postid'=>$postId, ':email'=>$email))) {
                        $db->query2('UPDATE posts SET flags=flags+1 WHERE id=:postid', array(':postid'=>$postId));
                        $db->query2('INSERT INTO post_flag(post_id,email) VALUES (:postid, :email)', array(':postid'=>$postId, ':email'=>$email));
                        //Notify::createNotify([],$postId);
                } else {
                        $db->query2('UPDATE posts SET flags=flags-1 WHERE id=:postid', array(':postid'=>$postId));
                        $db->query2('DELETE FROM post_flag WHERE post_id=:postid AND email=:email', array(':postid'=>$postId, ':email'=>$email));
                }
                echo "{";
                echo '"Flags":';
                echo $db->query2('SELECT flags FROM posts WHERE id=:postid',array(':postid'=>$postId))[0]['flags'];
                echo "}";
        }

}  else if ($_SERVER['REQUEST_METHOD'] == "DELETE") {
        if ($_GET['url'] == "auth") {
                if (isset($_GET['token'])) {
                        if ($db->query("SELECT token FROM login_tokens WHERE token=:token", array(':token'=>sha1($_GET['token'])))) {
                                $db->query('DELETE FROM login_tokens WHERE token=:token', array(':token'=>sha1($_GET['token'])));
                                echo '{ "Status": "Success" }';
                                http_response_code(200);
                        } else {
                                echo '{ "Error": "Invalid token" }';
                                http_response_code(400);
                        }
                } else {
                        echo '{ "Error": "Malformed request" }';
                        http_response_code(400);
                }
        }
} else {
        http_response_code(405);
}
?>
