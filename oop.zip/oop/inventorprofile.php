<?php 
	require_once 'core/init.php';
    $user = new Inventor();
    //echo 
    if((time()-$_SESSION['last_time'])>3600):
      $user->logout();
      Session::flash('success','<div class="alert alert-danger">
                    Sorry!. Session timeout. please log in and try again.
                  </div>');
      Redirect::to('index.php');
    else:
      $_SESSION['last_time'] = time();
      if(isset($_POST["edit"])){
        Redirect::to("inventoredit.php");
      }
      elseif(isset($_POST["changepass"])){
        Redirect::to("changepassword.php");
      }
      elseif(isset($_POST["postview"])){
        Redirect::to("visitfacilitator.php?user=kalsara@gmail.com");
      }
      elseif(isset($_POST["addpost"])){
        Redirect::to("#");
      }
      elseif(isset($_POST["delete"])){
        Redirect::to("delete.php");
      }
      elseif (isset($_POST['save'])) {
        // if($_FILES['postimg']['size']==0){
        //     Post::createPost($_POST['postbody'],$_POST['link'],$user->data()->email);
        // }else{
          $category = Input::get('category');
            $newvalues = implode(",",$category);
            $postid = Post::createPost($_POST['postbody'],$_POST['link'],$newvalues,$user->data()->email);
            Image::uploadImage('postimg','UPDATE posts SET postimg=:postimg WHERE id=:postid',array('postid'=>$postid));
        //}
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Inventor account</title>
  <meta charset="utf-8">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/profile.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="http://use.fontawesome.com/d1341f9b7a.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" rel="stylesheet">
  <meta charset="utf-8">
  

</head>
<body>
  <div class="container-fluid">

  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="mi-modal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Do youy really want to logout?</h4>
      </div>
      <div class="modal-footer">
        <a href = "logout.php"><button type="button" class="btn btn-default" id="modal-btn-si">Yes</button></a>
        <a href = "index.php"><button type="button" class="btn btn-primary" id="modal-btn-no">No</button></a>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" role="dialog" id="newpost" tabindex="-1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <h4 class="modal-title">Add a new Post</h4>
                </div>
                <div class="modal-body">
                <form action="inventorprofile.php" method="post" enctype="multipart/form-data">
                    <div id="category" class="category" style="width: 568px;">
                        <p style="width: 100px;"><strong>Categories</strong></p>
                        <div class="checkbox"><label style="display: inline-flex;"><input type="checkbox"  value="Science" name="category[]">Science</label></div>
                        <div class="checkbox"><label style="display: inline-flex;"><input type="checkbox"  value="technology" name="category[]">Technology</label></div>
                        <div class="checkbox"><label style="display: inline-flex;"><input type="checkbox"  value="Business" name="category[]">Business</label></div>
                        <div class="checkbox"><label style="display: inline-flex;"><input type="checkbox"   value="Art-Design"name="category[]">Art/Design</label></div>
                        <div class="checkbox"><label style="display: inline-flex;"><input type="checkbox"   value="Education"name="category[]">Education</label></div>
                        <div class="checkbox"><label style="display: inline-flex;"><input type="checkbox"  value="Others" name="category[]">Others</label></div>
                    </div>
                    <div>
                    <div><p style="margin-top: 5px;"><strong>Description</strong></p>
                    <textarea name="postbody" rows="8" cols="75"></textarea></div>
                        <div>
                            <p style="margin-top: 5px;"><strong>Photos</strong></p><input type="file" name="postimg" style="width: 200px;"></div>
                        <div>
                            <p style="margin-top: 5px"><strong>video link</strong></p><input type="url" style="width:100%" name="link"></div>
                    </div>
                    <div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-primary" type="submit" name="save">Save</button></div>
                </form>
                </div>
                
            </div>
        </div>
    </div>


    <div class="row heading">
      <div class="container">
        <div class="col-md-3 col-sm-6">
          <img src="img/best.png">
        </div>
      </div>
    </div>

  <div class="row">
  <br>
  <?php if(Session::exists('edit')){
            echo Session::flash('edit');
          } ?>


      <div class="col-md-4">
          <div class="box">
          <img id="profile" src="img/img_avatar.png" alt="Avatar">
          <h1><?php echo escape($user->data()->firstname)." ".escape($user->data()->lastname) ?></h1>
                
          <h3>Inventor</h3>
          <br>      
          <div class ="main-container">
                  <p>I am interested in <strong><?php echo escape($user->data()->categories) ?><strong></p>
                  
                  <p><i class="fa fa-home info"></i><?php echo escape($user->data()->address)?></p>
                  
                  <p><i class="fa fa-envelope info"></i> <?php echo escape($user->data()->email)?></p>
                  
                  <p><i class="fa fa-phone info"></i> <?php echo escape($user->data()->phonenumber)?></p>

                  
                  <div class="bio">
                  <p><?php echo "\" ".escape($user->data()->bio)." \"" ?></p></div>
          </div>
          </div>          
      </div>
      <div class="col-md-8">
        <div class="row">
        <form method="post">
            <button type="submit" name="edit"><i class="fas fa-user-edit"></i>  Edit account</button>
            <button type="submit" name="changepass"><i class="fas fa-user-password"></i>  Edit password</button>
            <button type="submit" name="postview"><i class="fas fa-eye"></i>  View posts</button>
            <button type="submit" name="delete" style="margin-top:10px"><i class="fas fa-user-slash"></i>  Delete account</button>
        </form>
            <button type="submit" name="postadd" onclick="showNewPostModal()"><i class="fas fa-eye"></i>  Add posts</button>
            <button name="logout" id="btn-confirm" style="margin-top:10px"><i class="fas fa-sign-out-alt"></i> logout</button>
      </div>
        <div class="row">
          <div class="container tabs">
            <h2>What I have done</h2>
            <ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#home">Posts I have posted</a></li>
              <li><a data-toggle="tab" href="#menu1">Posts on negotiation</a></li>
              <li><a data-toggle="tab" href="#menu2">Posts I have taken offers</a></li>
            </ul>
            <div class="tab-content">
              <div id="home" class="tab-pane fade in active">
                <h3>0 posts</h3>
                <p> </p>
              </div>
              <div id="menu1" class="tab-pane fade">
                <h3>0 posts</h3>
                <p></p>
              </div>
              <div id="menu2" class="tab-pane fade">
                <h3>0 posts</h3>
                <p></p>
              </div>
            </div>
          </div>  
          <div>  
  </div>
</div>
</div>

<script>

var modalConfirm = function(callback){
  
  $("#btn-confirm").on("click", function(){
    $("#mi-modal").modal('show');
  });

  $("#modal-btn-si").on("click", function(){
    callback(true);
    $("#mi-modal").modal('hide');
  });
  
  $("#modal-btn-no").on("click", function(){
    callback(false);
    $("#mi-modal").modal('hide');
  });
};

modalConfirm(function(confirm){
  if(confirm){
    
  }else{
    
  }
});
function showNewPostModal() {
                $('#newpost').modal('show')
        }


</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
    <script type="text/javascript">
    var start = 5;
    var working = false;
    $(window).scroll(function() {
            if ($(this).scrollTop() + 1 >= $('body').height() - $(window).height()) {
                    if (working == false) {
                            working = true;
                            $.ajax({
                                    type: "GET",
                                    url: "api/profileposts?username=<?php echo $username; ?>&start="+start,
                                    processData: false,
                                    contentType: "application/json",
                                    data: '',
                                    success: function(r) {
                                            var posts = JSON.parse(r)
                                            $.each(posts, function(index) {
                                                    if (posts[index].PostImage == "") {
                                                            $('.timelineposts').html(
                                                                    $('.timelineposts').html() +
                                                                    '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><footer>Posted by '+posts[index].PostedBy+' on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Likes+' Likes</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments</span></button></footer></blockquote></li>'
                                                            )
                                                    } else {
                                                            $('.timelineposts').html(
                                                                    $('.timelineposts').html() +
                                                                    '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><img src="" data-tempsrc="'+posts[index].PostImage+'" class="postimg" style="opacity: 0;transition: all 2s ease-out;width:100%;" id="img'+posts[index].postId+'"><footer>Posted by '+posts[index].PostedBy+' on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Likes+' Likes</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments</span></button></footer></blockquote></li>'
                                                            )
                                                    }
                                                    $('[data-postid]').click(function() {
                                                            var buttonid = $(this).attr('data-postid');
                                                            $.ajax({
                                                                    type: "GET",
                                                                    url: "api/comments?postid=" + $(this).attr('data-postid'),
                                                                    processData: false,
                                                                    contentType: "application/json",
                                                                    data: '',
                                                                    success: function(r) {
                                                                            var res = JSON.parse(r)
                                                                            showCommentsModal(res);
                                                                    },
                                                                    error: function(r) {
                                                                            console.log(r)
                                                                    }
                                                            });
                                                    });
                                                    $('[data-id]').click(function() {
                                                            var buttonid = $(this).attr('data-id');
                                                            $.ajax({
                                                                    type: "POST",
                                                                    url: "api/likes?id=" + $(this).attr('data-id'),
                                                                    processData: false,
                                                                    contentType: "application/json",
                                                                    data: '',
                                                                    success: function(r) {
                                                                            var res = JSON.parse(r)
                                                                            $("[data-id='"+buttonid+"']").html(' <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+res.Likes+' Likes</span>')
                                                                    },
                                                                    error: function(r) {
                                                                            console.log(r)
                                                                    }
                                                            });
                                                    })
                                            })
                                            $('.postimg').each(function() {
                                                    this.src=$(this).attr('data-tempsrc')
                                                    this.onload = function() {
                                                            this.style.opacity = '1';
                                                    }
                                            })
                                            scrollToAnchor(location.hash)
                                            start+=5;
                                            setTimeout(function() {
                                                    working = false;
                                            }, 4000)
                                    },
                                    error: function(r) {
                                            console.log(r)
                                    }
                            });
                    }
            }
    })
    function scrollToAnchor(aid){
    try {
    var aTag = $(aid);
        $('html,body').animate({scrollTop: aTag.offset().top},'slow');
        } catch (error) {
                console.log(error)
        }
    }
        $(document).ready(function() {
                $.ajax({
                        type: "GET",
                        url: "api/profileposts?email=<?php echo $username; ?>&start=0",
                        processData: false,
                        contentType: "application/json",
                        data: '',
                        success: function(r) {
                                var posts = JSON.parse(r)
                                $.each(posts, function(index) {
                                        if (posts[index].PostImage == "") {
                                                $('.timelineposts').html(
                                                        $('.timelineposts').html() +
                                                        '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><footer>Posted by '+posts[index].PostedBy+' on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Likes+' Likes</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments</span></button></footer></blockquote></li>'
                                                )
                                        } else {
                                                $('.timelineposts').html(
                                                        $('.timelineposts').html() +
                                                        '<li class="list-group-item" id="'+posts[index].PostId+'"><blockquote><p>'+posts[index].PostBody+'</p><img src="" data-tempsrc="'+posts[index].PostImage+'" class="postimg" id="img'+posts[index].postId+'"><footer>Posted by '+posts[index].PostedBy+' on '+posts[index].PostDate+'<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;" data-id=\"'+posts[index].PostId+'\"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+posts[index].Likes+' Likes</span></button><button class="btn btn-default comment" data-postid=\"'+posts[index].PostId+'\" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"><i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> Comments</span></button></footer></blockquote></li>'
                                                )
                                        }
                                        $('[data-postid]').click(function() {
                                                var buttonid = $(this).attr('data-postid');
                                                $.ajax({
                                                        type: "GET",
                                                        url: "api/comments?postid=" + $(this).attr('data-postid'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                showCommentsModal(res);
                                                        },
                                                        error: function(r) {
                                                                console.log(r)
                                                        }
                                                });
                                        });
                                        $('[data-id]').click(function() {
                                                var buttonid = $(this).attr('data-id');
                                                $.ajax({
                                                        type: "POST",
                                                        url: "api/likes?id=" + $(this).attr('data-id'),
                                                        processData: false,
                                                        contentType: "application/json",
                                                        data: '',
                                                        success: function(r) {
                                                                var res = JSON.parse(r)
                                                                $("[data-id='"+buttonid+"']").html(' <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> '+res.Likes+' Likes</span>')
                                                        },
                                                        error: function(r) {
                                                                console.log(r)
                                                        }
                                                });
                                        })
                                })
                                $('.postimg').each(function() {
                                        this.src=$(this).attr('data-tempsrc')
                                        this.onload = function() {
                                                this.style.opacity = '1';
                                                this.style.width = '100%';
                                        }
                                })
                                scrollToAnchor(location.hash)
                        },
                        error: function(r) {
                                console.log(r)
                        }
                });
        });
        
        function showCommentsModal(res) {
                $('#commentsmodal').modal('show')
                var output = "";
                for (var i = 0; i < res.length; i++) {
                        output += res[i].Comment;
                        output += " ~ ";
                        output += res[i].CommentedBy;
                        output += "<hr />";
                }
                $('.modal-body').html(output)
        }
    </script>
</body>
</html>

<?php endif ?>

